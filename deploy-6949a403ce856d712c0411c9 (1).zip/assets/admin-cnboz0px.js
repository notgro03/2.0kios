import"./style-BmGd2xcR.js";import{s as a}from"./supabase-DYN4vMyM.js";let E=[],l=null;async function B(){await L(),await m(),_()}async function L(){const{data:t,error:e}=await a.from("product_categories").select("*").order("display_order");if(e){console.error("Error loading categories:",e),i("Error al cargar categorías","error");return}E=t,P()}function P(){document.querySelectorAll(".category-select").forEach(e=>{e.innerHTML='<option value="">Seleccionar categoría</option>',E.forEach(n=>{const o=document.createElement("option");o.value=n.id,o.textContent=n.name,e.appendChild(o)})})}async function m(t=null){let e=a.from("products").select(`
      *,
      product_categories (
        name,
        slug,
        icon
      )
    `).order("display_order");t&&(e=e.eq("category_id",t));const{data:n,error:o}=await e;if(o){console.error("Error loading products:",o),i("Error al cargar productos","error");return}$(n)}function $(t){const e=document.getElementById("productsList");if(e){if(t.length===0){e.innerHTML=`
      <div style="text-align: center; padding: 40px; color: rgba(255,255,255,0.5);">
        <i class="fas fa-inbox" style="font-size: 48px; margin-bottom: 16px;"></i>
        <p>No hay productos. Agrega tu primer producto.</p>
      </div>
    `;return}e.innerHTML=t.map(n=>`
    <div class="item-card" data-product-id="${n.id}">
      <div class="item-image">
        ${n.image_url?`<img src="${n.image_url}" alt="${n.title}" style="width: 100%; height: 100%; object-fit: cover; border-radius: 12px;">`:'<div style="width: 100%; height: 100%; background: rgba(255,255,255,0.1); border-radius: 12px; display: flex; align-items: center; justify-content: center;"><i class="fas fa-image" style="font-size: 32px; color: rgba(255,255,255,0.3);"></i></div>'}
      </div>
      <div class="item-info">
        <h4>${n.title}</h4>
        <p>
          <i class="fas ${n.product_categories?.icon||"fa-tag"}"></i>
          ${n.product_categories?.name||"Sin categoría"}
          ${n.price?` - $${parseFloat(n.price).toLocaleString("es-AR")}`:""}
        </p>
        <p style="font-size: 12px; opacity: 0.6;">
          ${n.brand||""} ${n.model||""}
          ${n.is_active?'<span style="color: #22c55e;">● Activo</span>':'<span style="color: #ef4444;">● Inactivo</span>'}
        </p>
      </div>
      <div class="item-actions">
        <button class="btn-icon" onclick="window.editProduct('${n.id}')" title="Editar">
          <i class="fas fa-edit"></i>
        </button>
        <button class="btn-icon delete" onclick="window.deleteProduct('${n.id}')" title="Eliminar">
          <i class="fas fa-trash"></i>
        </button>
      </div>
    </div>
  `).join("")}}function _(){const t=document.getElementById("filterCategory");t&&t.addEventListener("change",r=>{const c=r.target.value;m(c||null)});const e=document.getElementById("productForm");e&&e.addEventListener("submit",k);const n=document.getElementById("btnNewProduct");n&&n.addEventListener("click",x);const o=document.getElementById("btnCancelProduct");o&&o.addEventListener("click",I)}function x(){l=null;const t=document.getElementById("productModal"),e=document.getElementById("productForm");e&&e.reset(),document.getElementById("modalTitle").textContent="Nuevo Producto",t&&(t.style.display="flex")}function I(){const t=document.getElementById("productModal");t&&(t.style.display="none"),l=null}async function k(t){t.preventDefault();const e={category_id:document.getElementById("productCategory").value,title:document.getElementById("productTitle").value,description:document.getElementById("productDescription").value,image_url:document.getElementById("productImage").value,price:parseFloat(document.getElementById("productPrice").value)||0,stock:parseInt(document.getElementById("productStock").value)||0,brand:document.getElementById("productBrand").value,model:document.getElementById("productModel").value,is_active:document.getElementById("productActive").checked,display_order:parseInt(document.getElementById("productOrder").value)||0,features:[],compatibility:[]};try{if(l){const{error:n}=await a.from("products").update(e).eq("id",l);if(n)throw n;i("Producto actualizado correctamente","success")}else{const{error:n}=await a.from("products").insert([e]);if(n)throw n;i("Producto creado correctamente","success")}I(),await m()}catch(n){console.error("Error saving product:",n),i("Error al guardar el producto","error")}}window.editProduct=async function(t){l=t;const{data:e,error:n}=await a.from("products").select("*").eq("id",t).single();if(n){console.error("Error loading product:",n),i("Error al cargar el producto","error");return}document.getElementById("modalTitle").textContent="Editar Producto",document.getElementById("productCategory").value=e.category_id||"",document.getElementById("productTitle").value=e.title||"",document.getElementById("productDescription").value=e.description||"",document.getElementById("productImage").value=e.image_url||"",document.getElementById("productPrice").value=e.price||"",document.getElementById("productStock").value=e.stock||"",document.getElementById("productBrand").value=e.brand||"",document.getElementById("productModel").value=e.model||"",document.getElementById("productActive").checked=e.is_active,document.getElementById("productOrder").value=e.display_order||0;const o=document.getElementById("productModal");o&&(o.style.display="flex")};window.deleteProduct=async function(t){if(confirm("¿Estás seguro de que quieres eliminar este producto?"))try{const{error:e}=await a.from("products").delete().eq("id",t);if(e)throw e;i("Producto eliminado correctamente","success"),await m()}catch(e){console.error("Error deleting product:",e),i("Error al eliminar el producto","error")}};function i(t,e="info"){const n=document.createElement("div");n.className=`alert alert-${e}`,n.textContent=t,n.style.position="fixed",n.style.top="100px",n.style.right="20px",n.style.zIndex="10000",n.style.minWidth="300px",n.style.animation="slideIn 0.3s ease",document.body.appendChild(n),setTimeout(()=>{n.style.animation="slideOut 0.3s ease",setTimeout(()=>{n.remove()},300)},3e3)}document.addEventListener("DOMContentLoaded",async()=>{await h(),A()});async function h(){const{data:{user:t}}=await a.auth.getUser();if(!t){f();return}const{data:e}=await a.from("admin_users").select("*").eq("id",t.id).maybeSingle();if(!e){w("loginAlert","No tienes permisos de administrador","error"),await a.auth.signOut(),f();return}F(),M()}function f(){document.getElementById("loginSection").style.display="block",document.getElementById("adminSection").style.display="none"}function F(){document.getElementById("loginSection").style.display="none",document.getElementById("adminSection").style.display="block"}function A(){document.getElementById("loginForm")?.addEventListener("submit",S),document.getElementById("logoutBtn")?.addEventListener("click",q),document.querySelectorAll(".admin-tab").forEach(t=>{t.addEventListener("click",()=>C(t.dataset.tab))}),document.getElementById("gifForm")?.addEventListener("submit",T),document.getElementById("productForm")?.addEventListener("submit",handleProductSubmit),document.getElementById("planForm")?.addEventListener("submit",D)}async function S(t){t.preventDefault();const e=document.getElementById("loginEmail").value,n=document.getElementById("loginPassword").value,{data:o,error:r}=await a.auth.signInWithPassword({email:e,password:n});if(r){w("loginAlert",r.message,"error");return}await h()}async function q(){await a.auth.signOut(),f()}function C(t){document.querySelectorAll(".admin-tab").forEach(e=>{e.classList.remove("active")}),document.querySelector(`[data-tab="${t}"]`).classList.add("active"),document.querySelectorAll(".admin-content").forEach(e=>{e.classList.remove("active")}),document.getElementById(t).classList.add("active")}async function M(){await p(),await B(),await g()}async function p(){const{data:t,error:e}=await a.from("banner_gifs").select("*").order("order_position");if(e){console.error("Error loading gifs:",e);return}const n=document.getElementById("gifsList");n.innerHTML=t.map(o=>`
    <div class="item-card">
      <div class="item-info">
        <h4>${o.alt_text||"GIF sin título"}</h4>
        <p>${o.url}</p>
        <p style="font-size: 12px; color: rgba(255,255,255,0.5);">Orden: ${o.order_position}</p>
      </div>
      <div class="item-actions">
        <button class="btn-icon" onclick="toggleGifActive('${o.id}', ${!o.active})" title="${o.active?"Desactivar":"Activar"}">
          <i class="fas fa-${o.active?"eye":"eye-slash"}"></i>
        </button>
        <button class="btn-icon delete" onclick="deleteGif('${o.id}')" title="Eliminar">
          <i class="fas fa-trash"></i>
        </button>
      </div>
    </div>
  `).join("")}async function T(t){t.preventDefault();const e=document.getElementById("gifUrl").value,n=document.getElementById("gifAlt").value,o=parseInt(document.getElementById("gifOrder").value),{error:r}=await a.from("banner_gifs").insert([{url:e,alt_text:n,order_position:o}]);if(r){alert("Error al guardar el GIF: "+r.message);return}document.getElementById("gifForm").reset(),await p(),alert("GIF guardado exitosamente")}window.toggleGifActive=async function(t,e){const{error:n}=await a.from("banner_gifs").update({active:e}).eq("id",t);n||await p()};window.deleteGif=async function(t){if(!confirm("¿Estás seguro de eliminar este GIF?"))return;const{error:e}=await a.from("banner_gifs").delete().eq("id",t);e||await p()};async function g(){const{data:t,error:e}=await a.from("plans").select("*").order("order_position");if(e){console.error("Error loading plans:",e);return}const n=document.getElementById("plansList");n.innerHTML=t.map(o=>`
    <div class="item-card">
      <div class="item-info">
        <h4>${o.name} ${o.highlight?'<i class="fas fa-star" style="color: gold;"></i>':""}</h4>
        <p>${o.description}</p>
        <p style="font-size: 14px; color: rgba(255,255,255,0.8); margin-top: 8px;">
          <strong>${o.price} ${o.currency}</strong> | Orden: ${o.order_position}
        </p>
      </div>
      <div class="item-actions">
        <button class="btn-icon" onclick="editPlan('${o.id}')" title="Editar">
          <i class="fas fa-edit"></i>
        </button>
        <button class="btn-icon" onclick="togglePlanActive('${o.id}', ${!o.active})" title="${o.active?"Desactivar":"Activar"}">
          <i class="fas fa-${o.active?"eye":"eye-slash"}"></i>
        </button>
        <button class="btn-icon delete" onclick="deletePlan('${o.id}')" title="Eliminar">
          <i class="fas fa-trash"></i>
        </button>
      </div>
    </div>
  `).join("")}async function D(t){t.preventDefault();const e=document.getElementById("planId").value,n=document.getElementById("planName").value,o=document.getElementById("planDescription").value,r=parseFloat(document.getElementById("planPrice").value),c=document.getElementById("planCurrency").value,d=document.getElementById("planHighlight").checked,b=parseInt(document.getElementById("planOrder").value),y=[];document.querySelectorAll(".plan-feature-input").forEach(u=>{u.value.trim()&&y.push(u.value.trim())});const v={name:n,description:o,price:r,currency:c,features:JSON.stringify(y),highlight:d,order_position:b};let s;if(e?s=(await a.from("plans").update(v).eq("id",e)).error:s=(await a.from("plans").insert([v])).error,s){alert("Error al guardar el plan: "+s.message);return}document.getElementById("planForm").reset(),document.getElementById("planId").value="",N(),await g(),alert("Plan guardado exitosamente")}window.editPlan=async function(t){const{data:e,error:n}=await a.from("plans").select("*").eq("id",t).single();if(n){alert("Error al cargar el plan");return}document.getElementById("planId").value=e.id,document.getElementById("planName").value=e.name,document.getElementById("planDescription").value=e.description,document.getElementById("planPrice").value=e.price,document.getElementById("planCurrency").value=e.currency,document.getElementById("planHighlight").checked=e.highlight,document.getElementById("planOrder").value=e.order_position;const o=document.getElementById("planFeaturesList");o.innerHTML="",(typeof e.features=="string"?JSON.parse(e.features):e.features).forEach(c=>{const d=document.createElement("div");d.className="feature-item",d.innerHTML=`
      <input type="text" class="plan-feature-input" value="${c}">
      <button type="button" class="btn-icon" onclick="removePlanFeature(this)">
        <i class="fas fa-times"></i>
      </button>
    `,o.appendChild(d)}),document.getElementById("planForm").scrollIntoView({behavior:"smooth"})};window.togglePlanActive=async function(t,e){const{error:n}=await a.from("plans").update({active:e}).eq("id",t);n||await g()};window.deletePlan=async function(t){if(!confirm("¿Estás seguro de eliminar este plan?"))return;const{error:e}=await a.from("plans").delete().eq("id",t);e||await g()};window.addPlanFeature=function(){const t=document.getElementById("planFeaturesList"),e=document.createElement("div");e.className="feature-item",e.innerHTML=`
    <input type="text" class="plan-feature-input" placeholder="Nueva característica">
    <button type="button" class="btn-icon" onclick="removePlanFeature(this)">
      <i class="fas fa-times"></i>
    </button>
  `,t.appendChild(e)};window.removePlanFeature=function(t){t.parentElement.remove()};function N(){const t=document.getElementById("planFeaturesList");t.innerHTML=`
    <div class="feature-item">
      <input type="text" class="plan-feature-input" placeholder="Característica 1">
      <button type="button" class="btn-icon" onclick="removePlanFeature(this)">
        <i class="fas fa-times"></i>
      </button>
    </div>
  `}function w(t,e,n){const o=document.getElementById(t);o.innerHTML=`<div class="alert alert-${n}">${e}</div>`,setTimeout(()=>{o.innerHTML=""},5e3)}
