import"./style-BmGd2xcR.js";import{s as n}from"./supabase-DYN4vMyM.js";import"./main-CpqrQyDF.js";class m{constructor(){this.cart=[],this.listeners=[],this.init()}async init(){const t=this.getSession();t&&t.user?await this.loadCartFromDB():this.loadCartFromLocal(),this.updateCartUI()}getSession(){const t=localStorage.getItem("kioskeys_session");if(t)try{return JSON.parse(t)}catch{return null}return null}loadCartFromLocal(){const t=localStorage.getItem("kioskeys_cart");if(t)try{this.cart=JSON.parse(t)}catch{this.cart=[]}}async loadCartFromDB(){const t=this.getSession();if(!(!t||!t.user))try{const{data:a,error:s}=await n.from("cart").select("*").eq("user_id",t.user.id);if(s)throw s;this.cart=a||[],this.notifyListeners()}catch(a){console.error("Error loading cart from DB:",a),this.loadCartFromLocal()}}saveCartToLocal(){localStorage.setItem("kioskeys_cart",JSON.stringify(this.cart))}async saveCartToDB(){const t=this.getSession();if(!t||!t.user){this.saveCartToLocal();return}try{if(await n.from("cart").delete().eq("user_id",t.user.id),this.cart.length>0){const a=this.cart.map(i=>({user_id:t.user.id,product_id:i.product_id,product_type:i.product_type,quantity:i.quantity,variant_data:i.variant_data||{},price_snapshot:i.price_snapshot})),{error:s}=await n.from("cart").insert(a);if(s)throw s}}catch(a){console.error("Error saving cart to DB:",a),this.saveCartToLocal()}}async addToCart(t){const{product_id:a,product_type:s,name:i,price:r,quantity:d=1,variant_data:u={},image:f=null}=t,p=this.cart.findIndex(l=>l.product_id===a&&l.product_type===s&&JSON.stringify(l.variant_data)===JSON.stringify(u));return p!==-1?this.cart[p].quantity+=d:this.cart.push({id:Date.now().toString(),product_id:a,product_type:s,name:i,price_snapshot:r,quantity:d,variant_data:u,image:f,created_at:new Date().toISOString()}),await this.saveCartToDB(),this.updateCartUI(),this.notifyListeners(),this.showCartNotification(i,d),!0}async updateQuantity(t,a){const s=this.cart.find(i=>i.id===t||i.product_id===t);return s?a<=0?await this.removeFromCart(t):(s.quantity=a,await this.saveCartToDB(),this.updateCartUI(),this.notifyListeners(),!0):!1}async removeFromCart(t){return this.cart=this.cart.filter(a=>a.id!==t&&a.product_id!==t),await this.saveCartToDB(),this.updateCartUI(),this.notifyListeners(),!0}async clearCart(){this.cart=[],await this.saveCartToDB(),this.updateCartUI(),this.notifyListeners()}getCart(){return this.cart}getItemCount(){return this.cart.reduce((t,a)=>t+a.quantity,0)}getSubtotal(){return this.cart.reduce((t,a)=>t+a.price_snapshot*a.quantity,0)}calculateDiscount(t=null){const a=this.getSubtotal();let s=0;if(t)switch(t.name){case"Plan Básico":s=.2;break;case"Plan Familiar":s=.2;break;case"Plan Flotas":s=.3;break}return a*s}getTotal(t=null,a=0){const s=this.getSubtotal(),i=this.calculateDiscount(t);return s-i+a}updateCartUI(){const t=document.querySelector(".cart-badge"),a=document.querySelector(".cart-count"),s=this.getItemCount();t&&(t.textContent=s,t.style.display=s>0?"flex":"none"),a&&(a.textContent=s)}showCartNotification(t,a){const s=document.createElement("div");s.className="cart-notification",s.innerHTML=`
      <div class="cart-notification-content">
        <i class="fas fa-check-circle"></i>
        <span>${a} x ${t} agregado al carrito</span>
      </div>
    `,document.body.appendChild(s),setTimeout(()=>{s.classList.add("show")},100),setTimeout(()=>{s.classList.remove("show"),setTimeout(()=>{s.remove()},300)},3e3)}subscribe(t){this.listeners.push(t)}unsubscribe(t){this.listeners=this.listeners.filter(a=>a!==t)}notifyListeners(){this.listeners.forEach(t=>t(this.cart))}async migrateLocalCartToDB(t){const a=this.cart;if(a.length!==0)try{const s=a.map(r=>({user_id:t,product_id:r.product_id,product_type:r.product_type,quantity:r.quantity,variant_data:r.variant_data||{},price_snapshot:r.price_snapshot})),{error:i}=await n.from("cart").insert(s);if(i)throw i;localStorage.removeItem("kioskeys_cart"),await this.loadCartFromDB()}catch(s){console.error("Error migrating cart:",s)}}}const e=new m,h=document.createElement("style");h.textContent=`
  .cart-notification {
    position: fixed;
    bottom: 24px;
    right: 24px;
    background: linear-gradient(135deg, rgba(0, 59, 142, 0.95), rgba(0, 114, 188, 0.95));
    color: white;
    padding: 16px 24px;
    border-radius: 16px;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
    z-index: 10000;
    transform: translateY(100px);
    opacity: 0;
    transition: all 0.3s ease;
    border: 2px solid rgba(255, 255, 255, 0.2);
  }

  .cart-notification.show {
    transform: translateY(0);
    opacity: 1;
  }

  .cart-notification-content {
    display: flex;
    align-items: center;
    gap: 12px;
  }

  .cart-notification-content i {
    font-size: 20px;
    color: rgba(134, 239, 172, 1);
  }

  @media (max-width: 768px) {
    .cart-notification {
      bottom: 16px;
      right: 16px;
      left: 16px;
      padding: 12px 16px;
    }
  }
`;document.head.appendChild(h);function c(){const o=document.getElementById("cartContent"),t=e.getCart();if(t.length===0){o.innerHTML=`
          <div class="empty-cart">
            <i class="fas fa-shopping-cart"></i>
            <h2>Tu carrito está vacío</h2>
            <p>Agrega productos para comenzar tu compra</p>
            <a href="/pages/productos.html" class="shop-btn">
              <i class="fas fa-store"></i>
              Ir a la tienda
            </a>
          </div>
        `;return}const a=e.getSubtotal(),s=e.calculateDiscount(),i=e.getTotal();o.innerHTML=`
        <div class="cart-content">
          <div class="cart-items">
            ${t.map(r=>`
              <div class="cart-item" data-item-id="${r.id||r.product_id}">
                <div class="item-image">
                  ${r.image?`<img src="${r.image}" alt="${r.name}">`:'<i class="fas fa-key"></i>'}
                </div>
                <div class="item-details">
                  <div class="item-name">${r.name}</div>
                  <div class="item-variant">${r.variant_data?.brand||""} ${r.variant_data?.model||""}</div>
                  <div class="item-price">$${r.price_snapshot.toFixed(2)}</div>
                </div>
                <div class="item-actions">
                  <button class="remove-btn" onclick="removeItem('${r.id||r.product_id}')">
                    <i class="fas fa-trash"></i>
                  </button>
                  <div class="quantity-control">
                    <button class="quantity-btn" onclick="updateQuantity('${r.id||r.product_id}', ${r.quantity-1})">
                      <i class="fas fa-minus"></i>
                    </button>
                    <span class="quantity-value">${r.quantity}</span>
                    <button class="quantity-btn" onclick="updateQuantity('${r.id||r.product_id}', ${r.quantity+1})">
                      <i class="fas fa-plus"></i>
                    </button>
                  </div>
                </div>
              </div>
            `).join("")}
          </div>
          <div class="cart-summary">
            <h3 class="summary-title">Resumen</h3>
            <div class="summary-row">
              <span>Subtotal:</span>
              <span>$${a.toFixed(2)}</span>
            </div>
            ${s>0?`
              <div class="summary-row discount">
                <span>Descuento:</span>
                <span>-$${s.toFixed(2)}</span>
              </div>
            `:""}
            <div class="summary-row">
              <span>Envío:</span>
              <span>A calcular</span>
            </div>
            <div class="summary-row total">
              <span>Total:</span>
              <span>$${i.toFixed(2)}</span>
            </div>
            <button class="checkout-btn" onclick="goToCheckout()">
              <i class="fas fa-credit-card"></i>
              Continuar al Checkout
            </button>
            <a href="/pages/productos.html" style="display: block; text-align: center; color: rgba(255, 255, 255, 0.7); margin-top: 20px; text-decoration: none;">
              <i class="fas fa-arrow-left"></i> Seguir comprando
            </a>
          </div>
        </div>
      `}window.removeItem=async o=>{confirm("¿Eliminar este producto del carrito?")&&(await e.removeFromCart(o),c())};window.updateQuantity=async(o,t)=>{t<1||(await e.updateQuantity(o,t),c())};window.goToCheckout=()=>{if(!localStorage.getItem("kioskeys_session")){alert("Debes iniciar sesión para continuar"),window.location.href="/pages/login.html";return}window.location.href="/pages/checkout.html"};e.subscribe(()=>c());c();
