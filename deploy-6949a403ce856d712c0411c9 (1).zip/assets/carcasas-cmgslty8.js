import"./style-BmGd2xcR.js";import{b as t}from"./media-modal-gNu2eFwp.js";import{i as n}from"./navigation-BsEoFjC-.js";import{s as i}from"./category-search-CfhOuAdq.js";import{s as d}from"./supabase-DYN4vMyM.js";import"./main-CpqrQyDF.js";const l="541157237390";function p(a){return`<div class="search-message" style="grid-column: 1/-1; padding: 40px;">
    <i class="fas fa-spinner fa-spin" style="font-size: 28px; margin-bottom: 12px; display: block;"></i>
    ${a}
  </div>`}function c(a){return`<div class="search-message" style="grid-column: 1/-1; padding: 48px 20px;">
    <i class="fas fa-shield-alt" style="font-size: 56px; margin-bottom: 16px; display: block; opacity: 0.55;"></i>
    ${a}
  </div>`}function m({image_url:a,video_url:e,brand:s,model:r}){return e&&e.trim()!==""?`<video autoplay loop muted playsinline>
      <source src="${e}" type="video/mp4">
    </video>`:a&&a.trim()!==""?`<img src="${a}" alt="Carcasa ${s} ${r}" data-image="${a}">`:`<div class="catalog-card__placeholder">
    <i class="fas fa-shield-alt"></i>
  </div>`}function f({brand:a,model:e,description:s}){const r=`Hola, me interesa obtener una cotización para el siguiente producto: ${a} ${e} ${s||""}`;return`https://api.whatsapp.com/send/?phone=${l}&text=${encodeURIComponent(r)}`}async function u(){const a=document.getElementById("productsGrid");if(a){a.innerHTML=p("Cargando carcasas...");try{const{data:e,error:s}=await d.from("carcasas").select("*").order("brand",{ascending:!0}).order("model",{ascending:!0});if(s){console.error("Error loading carcasas:",s),a.innerHTML=c("Error al cargar las carcasas");return}if(!e||e.length===0){a.innerHTML=c("No hay carcasas disponibles");return}a.innerHTML=e.map(r=>{const o=f(r);return`
        <article class="catalog-card">
          <div class="catalog-card__media">
            ${m(r)}
          </div>
          <div class="catalog-card__body">
            <h3 class="catalog-card__title">Carcasa ${r.brand} ${r.model}</h3>
            ${r.description?`<p class="catalog-card__description">${r.description}</p>`:""}
            <a href="${o}" target="_blank" rel="noopener" class="catalog-card__cta">
              <i class="fab fa-whatsapp"></i>
              Consultar
            </a>
          </div>
        </article>
      `}).join(""),t(a,".catalog-card__media img")}catch(e){console.error("Unexpected error:",e),a.innerHTML=c("Error al cargar las carcasas")}}}document.addEventListener("DOMContentLoaded",()=>{n("carcasas"),i({table:"carcasas",brandSelectId:"carcasasBrand",modelSelectId:"carcasasModel",resultsContainerId:"carcasasResults",searchButtonSelector:"#carcasasSearch",whatsappNumber:"541157237390",productLabel:"carcasa",modelLabel:"Modelo",fallbackIcon:"fas fa-shield-alt",emptyMessage:"No se encontraron carcasas para este modelo.",features:[{icon:"fas fa-shield-alt",text:"Protección reforzada"},{icon:"fas fa-screwdriver-wrench",text:"Incluye accesorios de montaje"},{icon:"fas fa-bolt",text:"Botonera lista para usar"}],buildTitle:({brand:a,model:e})=>`Carcasa ${a} ${e}`,buildWhatsappMessage:({brand:a,model:e,item:s,productLabel:r})=>`Hola, me interesa obtener una cotización para la siguiente ${r}:

Marca: ${a}
Modelo: ${e}
Descripción: ${s.description||"No disponible"}

¿Podrían brindarme información sobre el precio y disponibilidad?`}),u()});
