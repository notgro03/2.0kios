import"./style-BmGd2xcR.js";import{b as s}from"./media-modal-gNu2eFwp.js";import{i}from"./navigation-BsEoFjC-.js";import{s as c}from"./category-search-CfhOuAdq.js";import{s as d}from"./supabase-DYN4vMyM.js";import"./main-CpqrQyDF.js";const l="541157237390";function p(a){return`<div class="search-message" style="grid-column: 1/-1; padding: 40px;">
    <i class="fas fa-spinner fa-spin" style="font-size: 28px; margin-bottom: 12px; display: block;"></i>
    ${a}
  </div>`}function n(a){return`<div class="search-message" style="grid-column: 1/-1; padding: 48px 20px;">
    <i class="fas fa-car" style="font-size: 56px; margin-bottom: 16px; display: block; opacity: 0.55;"></i>
    ${a}
  </div>`}function m({image_url:a,video_url:e,brand:r,model:o}){return e&&e.trim()!==""?`<video autoplay loop muted playsinline>
      <source src="${e}" type="video/mp4">
    </video>`:a&&a.trim()!==""?`<img src="${a}" alt="Telemando ${r} ${o}" data-image="${a}">`:`<div class="catalog-card__placeholder">
    <i class="fas fa-car"></i>
  </div>`}function f({brand:a,model:e,description:r}){const o=`Hola, me interesa obtener una cotización para el siguiente producto: ${a} ${e} ${r||""}`;return`https://api.whatsapp.com/send/?phone=${l}&text=${encodeURIComponent(o)}`}async function u(){const a=document.getElementById("productsGrid");if(a){a.innerHTML=p("Cargando telemandos...");try{const{data:e,error:r}=await d.from("telemandos").select("*").order("brand",{ascending:!0}).order("model",{ascending:!0});if(r){console.error("Error loading telemandos:",r),a.innerHTML=n("Error al cargar los telemandos");return}if(!e||e.length===0){a.innerHTML=n("No hay telemandos disponibles");return}a.innerHTML=e.map(o=>{const t=f(o);return`
        <article class="catalog-card">
          <div class="catalog-card__media">
            ${m(o)}
          </div>
          <div class="catalog-card__body">
            <h3 class="catalog-card__title">Telemando ${o.brand} ${o.model}</h3>
            ${o.description?`<p class="catalog-card__description">${o.description}</p>`:""}
            <a href="${t}" target="_blank" rel="noopener" class="catalog-card__cta">
              <i class="fab fa-whatsapp"></i>
              Consultar
            </a>
          </div>
        </article>
      `}).join(""),s(a,".catalog-card__media img")}catch(e){console.error("Unexpected error:",e),a.innerHTML=n("Error al cargar los telemandos")}}}document.addEventListener("DOMContentLoaded",()=>{i("telemandos"),c({table:"telemandos",brandSelectId:"brandSelect",modelSelectId:"modelSelect",resultsContainerId:"searchResults",searchButtonSelector:"#telemandosSearchButton",whatsappNumber:"541157237390",productLabel:"telemando",modelLabel:"Modelo",fallbackIcon:"fas fa-car",emptyMessage:"No se encontraron telemandos para este modelo.",features:[{icon:"fas fa-check-circle",text:"Alta compatibilidad"},{icon:"fas fa-shield-alt",text:"Garantía 1 año"},{icon:"fas fa-tools",text:"Programación incluida"}],buildTitle:({brand:a,model:e,item:r})=>`Telemando ${a} ${r.description?r.description:e}`,buildWhatsappMessage:({brand:a,model:e,item:r,productLabel:o})=>`Hola, me interesa obtener una cotización para el siguiente ${o}:

Marca: ${a}
Modelo: ${e}
Descripción: ${r.description||"No disponible"}

¿Podrían brindarme información sobre el precio y disponibilidad?`}),u()});
