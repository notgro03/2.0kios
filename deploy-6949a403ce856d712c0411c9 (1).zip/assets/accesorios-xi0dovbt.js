import"./style-BmGd2xcR.js";import{b as d}from"./media-modal-gNu2eFwp.js";import{i as p}from"./navigation-BsEoFjC-.js";import{s as n}from"./supabase-DYN4vMyM.js";import"./main-CpqrQyDF.js";const m="541157237390";function g(a){return`<div class="search-message" style="grid-column: 1/-1; padding: 40px;">
    <i class="fas fa-spinner fa-spin" style="font-size: 28px; margin-bottom: 12px; display: block;"></i>
    ${a}
  </div>`}function r(a){return`<div class="search-message" style="grid-column: 1/-1; padding: 48px 20px;">
    <i class="fas fa-tools" style="font-size: 56px; margin-bottom: 16px; display: block; opacity: 0.55;"></i>
    ${a}
  </div>`}function f({image_url:a}){return a&&a.trim()!==""?`<img src="${a}" alt="Accesorio Kioskeys" data-image="${a}">`:`<div class="catalog-card__placeholder">
    <i class="fas fa-toolbox"></i>
  </div>`}function _(a){const o=`Hola, me interesa el siguiente accesorio: ${[a.title,a.brand,a.model].filter(Boolean).join(" ")}. ¿Podrían brindarme información sobre precio y disponibilidad?`;return`https://api.whatsapp.com/send/?phone=${m}&text=${encodeURIComponent(o)}&type=phone_number&app_absent=0`}async function b(){const a=document.getElementById("productsGrid");if(a){a.innerHTML=g("Cargando accesorios...");try{const{data:e}=await n.from("product_categories").select("*").eq("slug","accesorios").maybeSingle();if(!e){a.innerHTML=r("No se encontró la categoría de accesorios.");return}const{data:o,error:t}=await n.from("products").select("*").eq("category_id",e.id).eq("is_active",!0).order("display_order");if(t){console.error("Error loading products:",t),a.innerHTML=r("Error al cargar los accesorios.");return}if(!o||o.length===0){a.innerHTML=r("No hay accesorios disponibles en este momento.");return}a.innerHTML=o.map(s=>{const l=_(s),i=typeof s.stock=="number"?s.stock>0:!0,c=Number(s.price||0);return`
        <article class="catalog-card">
          <div class="catalog-card__media">
            ${f(s)}
            <span class="catalog-card__status ${i?"catalog-card__status--available":"catalog-card__status--soldout"}">
              <i class="fas ${i?"fa-check-circle":"fa-times-circle"}"></i>
              ${i?"Disponible":"Agotado"}
            </span>
          </div>
          <div class="catalog-card__body">
            <h3 class="catalog-card__title">${s.title}</h3>
            ${s.brand||s.model?`<p class="catalog-card__meta"><i class="fas fa-tag"></i>${s.brand||""} ${s.model||""}</p>`:""}
            ${s.description?`<p class="catalog-card__description">${s.description}</p>`:""}
            <div class="catalog-card__footer">
              ${c>0?`<span class="catalog-card__price">$${c.toLocaleString("es-AR")}</span>`:'<span class="catalog-card__meta"><i class="fas fa-comment"></i> Consultar precio</span>'}
              <a href="${l}" target="_blank" rel="noopener" class="catalog-card__cta">
                <i class="fab fa-whatsapp"></i>
                Consultar
              </a>
            </div>
          </div>
        </article>
      `}).join(""),d(a,".catalog-card__media img")}catch(e){console.error("Error:",e),a.innerHTML=r("Error al cargar los accesorios.")}}}document.addEventListener("DOMContentLoaded",()=>{p("accesorios"),b()});
