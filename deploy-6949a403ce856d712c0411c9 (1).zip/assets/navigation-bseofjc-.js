const f=[{id:"inicio",label:"Inicio",href:"../index.html",rootHref:"./index.html",icon:"fas fa-home"},{id:"red-servicios",label:"Red de Servicios",href:"../pages/red-servicios.html",rootHref:"./pages/red-servicios.html",icon:"fas fa-map-marker-alt"},{id:"planes",label:"Planes",href:"../pages/planes.html",rootHref:"./pages/planes.html",icon:"fas fa-crown"},{id:"productos",label:"Productos",href:"../pages/productos.html",rootHref:"./pages/productos.html",icon:"fas fa-box"},{id:"faq",label:"FAQ",href:"../pages/faq.html",rootHref:"./pages/faq.html",icon:"fas fa-question-circle"},{id:"contacto",label:"Contacto",href:"../pages/contacto.html",rootHref:"./pages/contacto.html",icon:"fas fa-envelope"},{id:"descarga-app",label:"Descarga App",href:"../pages/descarga-app.html",rootHref:"./pages/descarga-app.html",icon:"fas fa-mobile-alt"}],g={telemandos:"productos",llaves:"productos",accesorios:"productos",carcasas:"productos"};function h(n=""){const e=document.querySelector("nav");if(!e){console.warn("[Navigation] Elemento <nav> no encontrado en la página actual.");return}const i=g[n]||n,t=window.location.pathname==="/"||window.location.pathname.endsWith("index.html"),r=t?"./images/LOGO_KIOSKEYS.png":"../images/LOGO_KIOSKEYS.png",d=a=>t?a.rootHref:a.href;e.innerHTML=`
    <div class="logo">
      <a href="${t?"./index.html":"../index.html"}">
        <img data-logo src="${r}" alt="Kioskeys" class="nav-logo-img">
      </a>
    </div>
    <div class="nav-links">
      ${f.map(a=>{const l=["shiny-text"];a.id===i&&l.push("active");const p=a.id===i?' aria-current="page"':"";return`
          <a href="${d(a)}" class="${l.join(" ")}" data-page="${a.id}"${p}>
            <i class="${a.icon}" aria-hidden="true"></i>
            <span>${a.label}</span>
          </a>
        `}).join("")}
    </div>
    <button class="menu-button" type="button" aria-label="Abrir menú de navegación">
      <i class="fas fa-bars" aria-hidden="true"></i>
    </button>
  `;const o=e.querySelector(".menu-button"),s=e.querySelector(".nav-links");o&&s&&(o.addEventListener("click",()=>{o.classList.toggle("active"),s.classList.toggle("active")}),s.addEventListener("click",a=>{a.target.tagName==="A"&&(o.classList.remove("active"),s.classList.remove("active"))}));let c=window.scrollY;window.addEventListener("scroll",()=>{const a=window.scrollY;a>c&&a>100?(e.classList.add("nav-hidden"),o.classList.remove("active"),s.classList.remove("active")):e.classList.remove("nav-hidden"),c=a})}export{h as i};
