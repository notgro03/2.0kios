import"./style-BmGd2xcR.js";import{b as n}from"./media-modal-gNu2eFwp.js";import{i}from"./navigation-BsEoFjC-.js";import{s as l}from"./category-search-CfhOuAdq.js";import{s as c}from"./supabase-DYN4vMyM.js";import"./main-CpqrQyDF.js";const d="541157237390";function p(a){return`<div class="search-message" style="grid-column: 1/-1; padding: 40px;">
    <i class="fas fa-spinner fa-spin" style="font-size: 28px; margin-bottom: 12px; display: block;"></i>
    ${a}
  </div>`}function s(a){return`<div class="search-message" style="grid-column: 1/-1; padding: 48px 20px;">
    <i class="fas fa-key" style="font-size: 56px; margin-bottom: 16px; display: block; opacity: 0.55;"></i>
    ${a}
  </div>`}function m({image_url:a,video_url:e,brand:o,model:r}){return e&&e.trim()!==""?`<video autoplay loop muted playsinline>
      <source src="${e}" type="video/mp4">
    </video>`:a&&a.trim()!==""?`<img src="${a}" alt="Llave ${o} ${r}" data-image="${a}">`:`<div class="catalog-card__placeholder">
    <i class="fas fa-key"></i>
  </div>`}function f({brand:a,model:e,description:o}){const r=`Hola, me interesa obtener una cotización para el siguiente producto: ${a} ${e} ${o||""}`;return`https://api.whatsapp.com/send/?phone=${d}&text=${encodeURIComponent(r)}`}async function u(){const a=document.getElementById("productsGrid");if(a){a.innerHTML=p("Cargando llaves...");try{const{data:e,error:o}=await c.from("llaves").select("*").order("brand",{ascending:!0}).order("model",{ascending:!0});if(o){console.error("Error loading llaves:",o),a.innerHTML=s("Error al cargar las llaves");return}if(!e||e.length===0){a.innerHTML=s("No hay llaves disponibles");return}a.innerHTML=e.map(r=>{const t=f(r);return`
        <article class="catalog-card">
          <div class="catalog-card__media">
            ${m(r)}
          </div>
          <div class="catalog-card__body">
            <h3 class="catalog-card__title">Llave ${r.brand} ${r.model}</h3>
            ${r.description?`<p class="catalog-card__description">${r.description}</p>`:""}
            <a href="${t}" target="_blank" rel="noopener" class="catalog-card__cta">
              <i class="fab fa-whatsapp"></i>
              Consultar
            </a>
          </div>
        </article>
      `}).join(""),n(a,".catalog-card__media img")}catch(e){console.error("Unexpected error:",e),a.innerHTML=s("Error al cargar las llaves")}}}document.addEventListener("DOMContentLoaded",()=>{i("llaves"),l({table:"llaves",brandSelectId:"llavesBrand",modelSelectId:"llavesModel",resultsContainerId:"llavesResults",searchButtonSelector:"#llavesSearch",whatsappNumber:"541157237390",productLabel:"llave",modelLabel:"Modelo",fallbackIcon:"fas fa-key",emptyMessage:"No se encontraron llaves para este modelo.",features:[{icon:"fas fa-check-circle",text:"Programación garantizada"},{icon:"fas fa-bolt",text:"Transponder listo para codificar"},{icon:"fas fa-headset",text:"Soporte especializado"}],buildTitle:({brand:a,model:e})=>`Llave ${a} ${e}`,buildWhatsappMessage:({brand:a,model:e,item:o,productLabel:r})=>`Hola, me interesa obtener una cotización para la siguiente ${r}:

Marca: ${a}
Modelo: ${e}
Descripción: ${o.description||"No disponible"}

¿Podrían brindarme información sobre el precio y disponibilidad?`}),u()});
