import{s as H}from"./supabase-DYN4vMyM.js";import{b as j}from"./media-modal-gNu2eFwp.js";const F="541157237390";function R({image_url:r,video_url:s,brand:d,model:p,fallbackIcon:u}){if(!!(s&&s.trim()))return`<div class="result-media" data-type="video">
      <video autoplay loop muted playsinline>
        <source src="${s}" type="video/mp4">
      </video>
    </div>`;if(r&&r.trim()){const y=`Producto ${d||""} ${p||""}`.trim()||"Producto";return`<div class="result-media" data-type="image" data-image="${r}">
      <img src="${r}" alt="${y}">
    </div>`}return`<div class="result-media result-media--placeholder" data-type="placeholder">
    <i class="${u||"fas fa-box-open"}"></i>
  </div>`}function V(r=[]){const s=typeof r=="function"?r():r;return s?.length?`<ul class="result-features">${s.map(({icon:p,text:u})=>`
    <li class="result-feature">
      <i class="${p}"></i>
      ${u}
    </li>
  `).join("")}</ul>`:""}function O({brand:r,model:s,item:d,productLabel:p}){const u=d?.description?d.description:"No disponible";return`Hola, me interesa obtener una cotización para el siguiente ${p}:

Marca: ${r}
Modelo: ${s}
Descripción: ${u}

¿Podrían brindarme información sobre el precio y disponibilidad?`}function z(r){const{table:s,brandSelectId:d,modelSelectId:p,resultsContainerId:u,searchButtonSelector:L,whatsappNumber:y=F,productLabel:$="producto",modelLabel:C="Modelo",emptyMessage:A="No se encontraron resultados para este modelo.",fallbackIcon:I,features:x=[],buildTitle:w,buildWhatsappMessage:P,buildMeta:B,buildFeatures:E}=r,f=document.getElementById(d),m=document.getElementById(p),c=document.getElementById(u),T=document.querySelector(L);if(!f||!m||!c||!T){console.warn("[setupCategorySearch] Missing required elements for category page");return}const g=new Map;async function k(){const{data:t,error:e}=await H.from(s).select("*").order("brand",{ascending:!0});if(e){console.error(`[setupCategorySearch] Error loading brands for ${s}:`,e);return}Array.from(new Set((t||[]).map(i=>i.brand).filter(Boolean))).forEach(i=>{const o=document.createElement("option");o.value=i,o.textContent=i,f.appendChild(o)})}async function q(t){try{const{data:e,error:l}=await H.from(s).select("*").eq("brand",t).order("model",{ascending:!0});if(l){console.error(`[setupCategorySearch] Error loading models for ${s}:`,l.message||l);return}const i=Array.isArray(e)?e:[],o=i.some(a=>Object.prototype.hasOwnProperty.call(a,"model"));o||console.error(`[setupCategorySearch] Missing "model" column in ${s} table response.`);const v=o?[...i].sort((a,n)=>{const M=(a.model??"").toString(),S=(n.model??"").toString();return M.localeCompare(S,"es",{sensitivity:"base"})}):i;g.clear(),m.innerHTML='<option value="">Seleccioná el modelo</option>';const b=v.reduce((a,n)=>(n.model&&(a[n.model]||(a[n.model]=[]),a[n.model].push(n)),a),{}),h=Object.keys(b);h.forEach(a=>{g.set(a,b[a]);const n=document.createElement("option");n.value=a,n.textContent=a,m.appendChild(n)}),m.disabled=h.length===0,h.length||(c.innerHTML='<p class="search-message">Pronto agregaremos modelos para esta marca.</p>',c.classList.add("active"))}catch(e){console.error("[setupCategorySearch] Unexpected error loading models:",e)}}function N(t,e,l=[]){if(!l.length){c.innerHTML=`<p class="search-message">${A}</p>`,c.classList.add("active");return}const i=l.map(o=>{const v=w?w({brand:t,model:e,item:o}):`${$.charAt(0).toUpperCase()}${$.slice(1)} ${t} ${e}`,b=B?B({brand:t,model:e,item:o,modelLabel:C}):e,h=t||"Sin marca",a=b||e||"No disponible",n=(P||O)({brand:t,model:e,item:o,productLabel:$}),M=`https://api.whatsapp.com/send/?phone=${y}&text=${encodeURIComponent(n)}&type=phone_number&app_absent=0`,S=V(()=>typeof E=="function"?E({brand:t,model:e,item:o}):x),U=`
        <div class="result-details">
          <p class="result-detail"><span>Marca:</span> ${h}</p>
          <p class="result-detail"><span>${C}:</span> ${a}</p>
        </div>
      `;return`
        <article class="result-item">
          ${R({...o,fallbackIcon:I})}
          <div class="result-info">
            <h3>${v}</h3>
            ${U}
            ${o.description?`<p>${o.description}</p>`:""}
            ${S}
          </div>
          <a class="result-button" href="${M}" target="_blank" rel="noopener">
            <i class="fab fa-whatsapp"></i>
            Consultar
          </a>
        </article>
      `}).join("");c.innerHTML=i,c.classList.add("active"),j(c,'.result-media[data-type="image"]')}f.addEventListener("change",async()=>{const t=f.value;if(m.disabled=!t,c.innerHTML="",c.classList.remove("active"),!t){m.innerHTML='<option value="">Seleccioná el modelo</option>',g.clear();return}await q(t)}),T.addEventListener("click",()=>{const t=f.value,e=m.value;if(!t||!e){c.innerHTML='<p class="search-message">Seleccioná una marca y un modelo para iniciar la búsqueda.</p>',c.classList.add("active");return}const l=g.get(e)||[];N(t,e,l)}),k()}export{z as s};
